/**
 * CyberShield UI logic.
 * Sections: Home, URL Scanner, Message Detector, Threat Analytics,
 * Scan History, Reports, About + AI Cyber Expert chat.
 * Scan history is stored in localStorage (no server needed).
 */
(function (global) {
  "use strict";

  const $ = (sel) => document.querySelector(sel);
  const $$ = (sel) => Array.from(document.querySelectorAll(sel));

  const HISTORY_KEY = "cybershield_history_v1";

  // ---------------------------------------------------------------- history
  function loadHistory() {
    try { return JSON.parse(localStorage.getItem(HISTORY_KEY) || "[]"); }
    catch { return []; }
  }
  function saveScan(entry) {
    const list = loadHistory();
    list.unshift(entry);
    if (list.length > 500) list.length = 500;
    localStorage.setItem(HISTORY_KEY, JSON.stringify(list));
  }
  function clearHistory() {
    localStorage.removeItem(HISTORY_KEY);
  }

  // ---------------------------------------------------------------- router
  function show(section) {
    $$("main > section[data-section]").forEach((s) => {
      s.hidden = s.dataset.section !== section;
    });
    $$(".nav-link").forEach((a) => a.classList.toggle("active", a.dataset.nav === section));
    window.scrollTo({ top: 0, behavior: "smooth" });
    if (section === "analytics") renderAnalytics();
    if (section === "history") renderHistory();
  }

  // ---------------------------------------------------------------- helpers
  function riskClass(label) {
    if (/malicious|phishing/i.test(label)) return "danger";
    if (/suspicious/i.test(label)) return "warn";
    return "safe";
  }

  function nowIso() { return new Date().toISOString(); }
  function fmtTime(iso) {
    const d = new Date(iso);
    return d.toLocaleDateString() + " " + d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  }

  function toast(msg, kind) {
    const el = document.createElement("div");
    el.className = "toast " + (kind || "info");
    el.textContent = msg;
    $("#toasts").appendChild(el);
    setTimeout(() => el.classList.add("show"), 10);
    setTimeout(() => { el.classList.remove("show"); setTimeout(() => el.remove(), 400); }, 3800);
  }

  // ---------------------------------------------------------------- URL scanner
  function scanUrl() {
    const url = $("#url-input").value.trim();
    const box = $("#url-result");
    if (!url) { toast("Enter a URL to scan.", "warn"); return; }
    const result = window.CyberML.analyzeUrl(url);
    box.hidden = false;

    const cls = riskClass(result.predictionLabel);
    box.innerHTML = `
      <div class="verdict ${cls}">
        <div class="verdict-icon">${cls === "safe"
          ? '<svg viewBox="0 0 24 24" width="34" height="34" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2l8 4v6c0 5-3.5 8.5-8 10-4.5-1.5-8-5-8-10V6l8-4z"/><path d="M9 12l2 2 4-4"/></svg>'
          : '<svg viewBox="0 0 24 24" width="34" height="34" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2l8 4v6c0 5-3.5 8.5-8 10-4.5-1.5-8-5-8-10V6l8-4z"/><path d="M12 8v4M12 16h.01"/></svg>'}</div>
        <div>
          <div class="verdict-label">${result.predictionLabel}</div>
          <div class="verdict-sub">Risk level: ${result.riskLevel}</div>
        </div>
        <div class="verdict-conf">
          <div class="conf-number">${result.confidence.toFixed(1)}%</div>
          <div class="conf-caption">model confidence</div>
        </div>
      </div>
      <div class="conf-bar"><div class="conf-fill ${cls}" style="width:${Math.min(100, result.confidence).toFixed(1)}%"></div></div>
      <div class="result-grid">
        <div class="card">
          <h4>Risk factors</h4>
          ${result.riskFactors.length
            ? '<ul class="risk-list">' + result.riskFactors.map((f) => `<li>${f}</li>`).join("") + "</ul>"
            : '<p class="muted">No obvious risk factors detected.</p>'}
          <div class="actions">
            <button class="btn ghost" id="url-ai-explain">AI explanation</button>
            <button class="btn ghost" id="url-ai-chat">Ask AI expert</button>
          </div>
          <div class="ai-panel" id="url-ai-out" hidden></div>
        </div>
        <div class="card">
          <h4>Extracted features (model input)</h4>
          <table class="feature-table">
            <thead><tr><th>Feature</th><th>Value</th></tr></thead>
            <tbody>${Object.entries(result.features).map(([k, v]) => `<tr><td>${k}</td><td class="mono">${v}</td></tr>`).join("")}</tbody>
          </table>
        </div>
      </div>`;
    box.hidden = false;

    saveScan({ type: "URL", input: url, prediction: result.predictionLabel, confidence: Number(result.confidence.toFixed(1)), risk_level: result.riskLevel, details: result.details, at: nowIso() });
    updateStats();

    $("#url-ai-explain").addEventListener("click", () => runAiInto($("#url-ai-out"), window.CyberAI.explainScan("url", url, result)));
    $("#url-ai-chat").addEventListener("click", () => {
      show("chat");
      $("#chat-input").value = "Is this URL safe to open: " + url;
      chatSend();
    });
  }

  // ---------------------------------------------------------------- message detector
  function scanMessage() {
    const text = $("#msg-input").value.trim();
    const box = $("#msg-result");
    if (!text) { toast("Enter a message to analyse.", "warn"); return; }
    const result = window.CyberML.analyzeMessage(text);
    const cls = riskClass(result.predictionLabel);

    box.innerHTML = `
      <div class="verdict ${cls}">
        <div class="verdict-icon">${cls === "safe"
          ? '<svg viewBox="0 0 24 24" width="34" height="34" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2l8 4v6c0 5-3.5 8.5-8 10-4.5-1.5-8-5-8-10V6l8-4z"/><path d="M9 12l2 2 4-4"/></svg>'
          : '<svg viewBox="0 0 24 24" width="34" height="34" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2l8 4v6c0 5-3.5 8.5-8 10-4.5-1.5-8-5-8-10V6l8-4z"/><path d="M12 8v4M12 16h.01"/></svg>'}</div>
        <div>
          <div class="verdict-label">${result.predictionLabel}</div>
          <div class="verdict-sub">Risk level: ${result.riskLevel}</div>
        </div>
        <div class="verdict-conf">
          <div class="conf-number">${result.confidence.toFixed(1)}%</div>
          <div class="conf-caption">model confidence</div>
        </div>
      </div>
      <div class="conf-bar"><div class="conf-fill ${cls}" style="width:${Math.min(100, result.confidence).toFixed(1)}%"></div></div>
      <div class="result-grid">
        <div class="card">
          <h4>Detected patterns</h4>
          ${result.patterns.length
            ? '<ul class="risk-list">' + result.patterns.map((f) => `<li>${f}</li>`).join("") + "</ul>"
            : '<p class="muted">No suspicious patterns detected.</p>'}
          <div class="actions">
            <button class="btn ghost" id="msg-ai-explain">AI explanation</button>
          </div>
          <div class="ai-panel" id="msg-ai-out" hidden></div>
        </div>
        <div class="card">
          <h4>What the model sees</h4>
          <p class="muted">TF-IDF vectoriser (773 features, 1-2 grams) + Multinomial Naive Bayes trained on
          labelled SMS/email examples. Class probabilities:</p>
          <div class="proba-row"><span>Legitimate</span><div class="conf-bar"><div class="conf-fill safe" style="width:${(result.proba[0] * 100).toFixed(1)}%"></div></div><span class="mono">${(result.proba[0] * 100).toFixed(1)}%</span></div>
          <div class="proba-row"><span>Phishing</span><div class="conf-bar"><div class="conf-fill danger" style="width:${(result.proba[1] * 100).toFixed(1)}%"></div></div><span class="mono">${(result.proba[1] * 100).toFixed(1)}%</span></div>
        </div>
      </div>`;
    box.hidden = false;

    saveScan({ type: "Message", input: text, prediction: result.predictionLabel, confidence: Number(result.confidence.toFixed(1)), risk_level: result.riskLevel, details: result.details, at: nowIso() });
    updateStats();

    $("#msg-ai-explain").addEventListener("click", () => runAiInto($("#msg-ai-out"), window.CyberAI.explainScan("message", text, result)));
  }

  // ---------------------------------------------------------------- AI helpers
  async function runAiInto(outBox, promise) {
    outBox.hidden = false;
    outBox.innerHTML = '<p class="muted">Asking the AI expert...</p>';
    const res = await promise;
    if (res.ok) {
      outBox.innerHTML = '<div class="ai-badge">AI explanation via ' + res.provider + '</div>' +
        '<div class="ai-text">' + escapeHtml(res.text).replace(/\n/g, "<br>") + "</div>";
    } else {
      outBox.innerHTML = '<div class="ai-badge warn">AI unavailable: ' + escapeHtml(res.error) +
        '.</div><p class="muted">The ML models keep working fully offline - verdicts above are unaffected.</p>';
    }
  }

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }

  // ---------------------------------------------------------------- chat
  const chatLog = [];
  function pushMsg(role, text) {
    chatLog.push({ role, text });
    renderChat();
  }
  function renderChat() {
    const log = $("#chat-log");
    log.innerHTML = chatLog.map((m) =>
      '<div class="chat-msg ' + (m.role === "user" ? "user" : "ai") + '"><div class="bubble">' +
      escapeHtml(m.text).replace(/\n/g, "<br>") + "</div></div>").join("");
    log.scrollTop = log.scrollHeight;
  }
  async function chatSend() {
    const input = $("#chat-input");
    const text = input.value.trim();
    if (!text) return;
    input.value = "";
    pushMsg("user", text);
    const typing = $("#chat-typing");
    typing.hidden = false;
    const res = await window.CyberAI.askAI(text, window.CyberAI.SYSTEM_PROMPT);
    typing.hidden = true;
    if (res.ok) pushMsg("ai", res.text);
    else pushMsg("ai", "AI is unavailable right now (" + res.error + "). The offline ML scanners still work - try the URL or Message tabs, or check the key in config.js.");
  }

  // ---------------------------------------------------------------- dashboard
  function scanStats() {
    const list = loadHistory();
    const urls = list.filter((s) => s.type === "URL");
    const msgs = list.filter((s) => s.type === "Message");
    const phish = list.filter((s) => /phishing|malicious/i.test(s.prediction)).length;
    return { total: list.length, urls: urls.length, msgs: msgs.length, phish };
  }

  function updateStats() {
    const s = scanStats();
    $("#stat-total").textContent = s.total;
    $("#stat-urls").textContent = s.urls;
    $("#stat-msgs").textContent = s.msgs;
    $("#stat-threats").textContent = s.phish;
  }

  let pieChart = null, barChart = null;
  function renderAnalytics() {
    const list = loadHistory();
    const s = scanStats();
    $("#analytics-empty").hidden = s.total > 0;
    $("#analytics-body").hidden = s.total === 0;
    if (s.total === 0) return;

    const safe = list.filter((x) => /legitimate/i.test(x.prediction)).length;
    const sus = list.filter((x) => /suspicious/i.test(x.risk_level)).length;
    const danger = list.filter((x) => /malicious|phishing detected/i.test(x.risk_level)).length;

    const pieCtx = $("#pie-chart");
    if (pieChart) pieChart.destroy();
    pieChart = new Chart(pieCtx, {
      type: "doughnut",
      data: {
        labels: ["Legitimate", "Suspicious", "Malicious / Phishing"],
        datasets: [{ data: [safe, sus, Math.max(0, s.phish - sus)], backgroundColor: ["#22c55e", "#f59e0b", "#ef4444"], borderColor: "#0b1220", borderWidth: 2 }],
      },
      options: { plugins: { legend: { labels: { color: "#cbd5e1" } } } },
    });

    // scans per day (last 7 days)
    const days = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date(); d.setDate(d.getDate() - i);
      days.push(d.toISOString().slice(0, 10));
    }
    const perDay = days.map((day) => list.filter((x) => (x.at || "").slice(0, 10) === day).length);
    const barCtx = $("#bar-chart");
    if (barChart) barChart.destroy();
    barChart = new Chart(barCtx, {
      type: "bar",
      data: {
        labels: days.map((d) => d.slice(5)),
        datasets: [{ label: "Scans", data: perDay, backgroundColor: "#22d3ee" }],
      },
      options: { plugins: { legend: { display: false } }, scales: { x: { ticks: { color: "#94a3b8" }, grid: { color: "#1e293b" } }, y: { beginAtZero: true, ticks: { color: "#94a3b8", precision: 0 }, grid: { color: "#1e293b" } } } },
    });
  }

  // ---------------------------------------------------------------- history table
  let historyFilter = "All";
  function renderHistory() {
    let list = loadHistory();
    if (historyFilter !== "All") {
      if (historyFilter === "URL" || historyFilter === "Message") list = list.filter((s) => s.type === historyFilter);
      else list = list.filter((s) => s.prediction.toLowerCase().includes(historyFilter.toLowerCase()));
    }
    const body = $("#history-tbody");
    $("#history-empty").hidden = list.length > 0;
    $("#history-table").hidden = list.length === 0;
    body.innerHTML = list.slice(0, 100).map((s) => `
      <tr>
        <td><span class="pill ${s.type === "URL" ? "pill-cyan" : "pill-violet"}">${s.type}</span></td>
        <td class="cell-input" title="${escapeHtml(s.input)}">${escapeHtml(s.input.length > 70 ? s.input.slice(0, 70) + "..." : s.input)}</td>
        <td><span class="pill ${riskClass(s.prediction) === "safe" ? "pill-green" : riskClass(s.prediction) === "warn" ? "pill-amber" : "pill-red"}">${s.prediction}</span></td>
        <td class="mono">${s.confidence.toFixed ? s.confidence.toFixed(1) : s.confidence}%</td>
        <td class="muted">${fmtTime(s.at)}</td>
      </tr>`).join("");
  }

  // ---------------------------------------------------------------- reports
  function downloadFile(name, content, mime) {
    const blob = new Blob([content], { type: mime });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = name;
    a.click();
    URL.revokeObjectURL(a.href);
  }

  function exportCsv() {
    const list = loadHistory();
    if (!list.length) { toast("No scans to export yet.", "warn"); return; }
    const rows = [["timestamp", "type", "input", "prediction", "confidence_percent", "risk_level", "details"]];
    list.forEach((s) => rows.push([s.at, s.type, s.input, s.prediction, s.confidence, s.risk_level, s.details]));
    const csv = rows.map((r) => r.map((c) => '"' + String(c).replace(/"/g, '""') + '"').join(",")).join("\n");
    downloadFile("cybershield_report_" + new Date().toISOString().slice(0, 10) + ".csv", csv, "text/csv");
    toast("CSV report downloaded.", "ok");
  }

  function exportTxt() {
    const list = loadHistory();
    if (!list.length) { toast("No scans to export yet.", "warn"); return; }
    const s = scanStats();
    const lines = [
      "AI CYBERSHIELD - SECURITY SCAN REPORT",
      "Generated: " + new Date().toLocaleString(),
      "",
      "SUMMARY",
      "  Total scans : " + s.total,
      "  URL scans   : " + s.urls,
      "  Messages    : " + s.msgs,
      "  Threats     : " + s.phish,
      "",
      "DETAILED LOG",
      "-".repeat(70),
    ];
    list.forEach((x, i) => {
      lines.push((i + 1) + ". [" + fmtTime(x.at) + "] " + x.type + " -> " + x.prediction +
        " (" + x.confidence + "% confidence, " + x.risk_level + ")");
      lines.push("   Input: " + x.input.slice(0, 120));
      lines.push("   Notes: " + x.details);
      lines.push("");
    });
    downloadFile("cybershield_report_" + new Date().toISOString().slice(0, 10) + ".txt", lines.join("\n"), "text/plain");
    toast("TXT report downloaded.", "ok");
  }

  // ---------------------------------------------------------------- boot
  function on(sel, ev, fn) {
    const el = $(sel);
    if (el) el.addEventListener(ev, fn);
  }

  document.addEventListener("DOMContentLoaded", () => {
    // nav
    $$(".nav-link").forEach((a) => a.addEventListener("click", (e) => { e.preventDefault(); show(a.dataset.nav); }));
    $$("[data-goto]").forEach((b) => b.addEventListener("click", (e) => { e.preventDefault(); show(b.dataset.goto); }));

    // scanners
    on("#url-scan-btn", "click", scanUrl);
    on("#url-input", "keydown", (e) => { if (e.key === "Enter") scanUrl(); });
    on("#msg-scan-btn", "click", scanMessage);
    $$(".sample-url").forEach((b) => b.addEventListener("click", () => { $("#url-input").value = b.dataset.url; scanUrl(); }));
    $$(".sample-msg").forEach((b) => b.addEventListener("click", () => { $("#msg-input").value = b.dataset.msg; scanMessage(); }));

    // chat
    on("#chat-send", "click", chatSend);
    on("#chat-input", "keydown", (e) => { if (e.key === "Enter") chatSend(); });

    // history + reports
    $$("[data-hfilter]").forEach((b) => b.addEventListener("click", () => {
      historyFilter = b.dataset.hfilter;
      $$("[data-hfilter]").forEach((x) => x.classList.toggle("active", x === b));
      renderHistory();
    }));
    on("#clear-history", "click", () => {
      if (confirm("Delete all saved scan history from this browser?")) {
        clearHistory(); renderHistory(); updateStats(); toast("History cleared.", "ok");
      }
    });
    on("#export-csv", "click", exportCsv);
    on("#export-txt", "click", exportTxt);
    on("#report-csv", "click", exportCsv);
    on("#report-txt", "click", exportTxt);

    // AI status chip
    const st = window.CyberAI.aiStatus();
    const chip = $("#ai-chip");
    chip.textContent = st.configured ? "AI Cyber Expert: " + st.provider : "AI expert offline (no key) - ML scans fully active";
    chip.className = "ai-chip " + (st.configured ? "" : "off");

    updateStats();
    pushMsg("ai", "Hello! I am the AI Cyber Expert. Ask me anything about phishing, suspicious links or safe browsing habits. Note: I answer via the API key configured in config.js - if the key is offline, the on-page ML scanners still work without me.");
    show("home");
  });
})(window);

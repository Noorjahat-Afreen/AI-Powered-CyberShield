/**
 * CyberShield browser-side ML inference engine.
 * Runs the REAL trained models (converted to JS) with zero server:
 *   - Random Forest phishing URL classifier (100 trees)
 *   - TF-IDF + Multinomial Naive Bayes message classifier
 * Mirrors scikit-learn semantics exactly (verified by scripts/parity_test.mjs).
 */
(function (global) {
  "use strict";

  // ------------------------------------------------------------------
  // 1. URL feature extraction - identical formulas to train_models.py
  // ------------------------------------------------------------------
  const SUSPICIOUS_TLDS = [".tk", ".ml", ".ga", ".cf", ".gq", ".top", ".xyz", ".club", ".work", ".click"];
  const SUSPICIOUS_WORDS = ["login", "verify", "update", "secure", "account", "password", "bank",
    "free", "winner", "prize", "gift", "claim", "urgent", "suspended",
    "limited", "offer", "bonus", "discount", "refund"];

  function extractUrlFeatures(url) {
    const features = {};
    features.url_length = url.length;
    features.num_dots = (url.match(/\./g) || []).length;
    features.num_hyphens = (url.match(/-/g) || []).length;
    features.num_underscores = (url.match(/_/g) || []).length;
    features.num_slashes = (url.match(/\//g) || []).length;
    features.num_digits = (url.match(/\d/g) || []).length;
    features.has_ip = /\d+\.\d+\.\d+\.\d+/.test(url) ? 1 : 0;
    features.has_at = url.indexOf("@") !== -1 ? 1 : 0;
    features.has_https = url.startsWith("https") ? 1 : 0;
    features.has_port = url.split("//").pop().split("/")[0].indexOf(":") !== -1 ? 1 : 0;
    features.num_subdomains = url.indexOf("//") !== -1
      ? (url.split("//").pop().split("/")[0].match(/\./g) || []).length
      : (url.match(/\./g) || []).length;
    const lower = url.toLowerCase();
    features.suspicious_tld = SUSPICIOUS_TLDS.some((t) => lower.indexOf(t) !== -1) ? 1 : 0;
    features.num_suspicious_words = SUSPICIOUS_WORDS.filter((w) => lower.indexOf(w) !== -1).length;
    features.has_double_slash_redirect = (url.match(/\/\//g) || []).length > 1 ? 1 : 0;
    features.has_percent = url.indexOf("%") !== -1 ? 1 : 0;
    features.has_equal_sign = url.indexOf("=") !== -1 ? 1 : 0;
    features.has_question = url.indexOf("?") !== -1 ? 1 : 0;
    return features;
  }

  // ------------------------------------------------------------------
  // 2. Random Forest inference (mirrors sklearn predict/predict_proba)
  // ------------------------------------------------------------------
  function treePredict(tree, x) {
    let node = 0;
    // sklearn stores TREE_UNDEFINED (-2) as the feature of leaf nodes
    while (tree.feature[node] >= 0) {
      const f = tree.feature[node];
      const v = x[f];
      node = v <= tree.threshold[node] ? tree.left[node] : tree.right[node];
    }
    return tree.value[node]; // raw class counts at leaf
  }

  function forestPredict(model, x) {
    const sums = new Array(model.classes.length).fill(0);
    for (const tree of model.trees) {
      const leaf = treePredict(tree, x);
      const total = leaf.reduce((a, b) => a + b, 0) || 1;
      for (let c = 0; c < leaf.length; c++) sums[c] += leaf[c] / total;
    }
    const n = model.trees.length;
    const proba = sums.map((s) => s / n);
    let best = 0;
    for (let c = 1; c < proba.length; c++) if (proba[c] > proba[best]) best = c;
    return { prediction: model.classes[best], proba };
  }

  // ------------------------------------------------------------------
  // 3. TF-IDF vectoriser (mirrors sklearn TfidfVectorizer transform)
  // ------------------------------------------------------------------
  // Python sklearn default token_pattern is "(?u)\\b\\w\\w+\\b"; (?u) is a Python
  // unicode flag (default in JS) so the JS equivalent is /\b\w\w+\b/g.
  const TOKEN_RE = /\b\w\w+\b/g;

  function tokenize(text) {
    // Python: str.lower() then regex findall
    const lowered = text.toLowerCase();
    return lowered.match(TOKEN_RE) || [];
  }

  function ngrams(tokens, n) {
    const out = [];
    for (let i = 0; i + n <= tokens.length; i++) out.push(tokens.slice(i, i + n).join(" "));
    return out;
  }

  function tfidfTransform(nbModel, text) {
    // sklearn order: tokenize -> LOWERCASE -> remove stop words -> build n-grams
    const tokens = tokenize(text);
    const stopSet = nbModel._stopSet || (nbModel._stopSet = new Set(nbModel.stop_words));
    const kept = tokens.filter((t) => !stopSet.has(t));
    const grams = kept.concat(
      kept.slice(0, -1).map((t, i) => kept[i] + " " + kept[i + 1])
    );
    const counts = new Map();
    for (const g of grams) {
      const idx = nbModel.vocabulary[g];
      if (idx === undefined) continue;
      counts.set(idx, (counts.get(idx) || 0) + 1);
    }
    // tf * idf, then L2 normalise
    let sq = 0;
    const pairs = [];
    counts.forEach((tf, idx) => {
      const val = tf * nbModel.idf[idx];
      pairs.push([idx, val]);
      sq += val * val;
    });
    const norm = Math.sqrt(sq) || 1;
    return pairs.map(([idx, val]) => [idx, val / norm]);
  }

  // ------------------------------------------------------------------
  // 4. Multinomial Naive Bayes inference (mirrors sklearn)
  // ------------------------------------------------------------------
  function nbPredict(model, sparseX) {
    const nClasses = model.classes.length;
    const jll = new Array(nClasses).fill(0);
    for (let c = 0; c < nClasses; c++) {
      let sum = model.class_log_prior[c];
      const w = model.feature_log_prob[c];
      for (const [idx, val] of sparseX) sum += val * w[idx];
      jll[c] = sum;
    }
    let best = 0;
    for (let c = 1; c < nClasses; c++) if (jll[c] > jll[best]) best = c;
    // softmax normalisation of joint log-likelihood (sklearn predict_proba)
    const maxJ = Math.max.apply(null, jll);
    const exps = jll.map((v) => Math.exp(v - maxJ));
    const total = exps.reduce((a, b) => a + b, 0);
    const proba = exps.map((e) => e / total);
    return { prediction: model.classes[best], proba };
  }

  // ------------------------------------------------------------------
  // 5. Public API - analyse + explain (mirrors app.py semantics)
  // ------------------------------------------------------------------
  function analyzeUrl(url) {
    const models = global.CYBER_MODELS;
    const features = extractUrlFeatures(url);
    const order = models.random_forest.feature_names;
    const x = order.map((f) => features[f]);
    const { prediction, proba } = forestPredict(models.random_forest, x);
    const confidence = Math.max.apply(null, proba) * 100;

    const riskFactors = [];
    if (features.has_ip) riskFactors.push("URL contains IP address instead of a domain name");
    if (features.has_at) riskFactors.push("URL contains '@' symbol (often hides the real destination)");
    if (features.suspicious_tld) riskFactors.push("Uses a suspicious top-level domain (.tk, .ml, .ga, .cf)");
    if (features.num_suspicious_words > 2) riskFactors.push("Contains " + features.num_suspicious_words + " suspicious keywords");
    if (features.url_length > 75) riskFactors.push("URL is unusually long (" + features.url_length + " characters)");
    if (features.num_dots > 4) riskFactors.push("Contains many dots (" + features.num_dots + ") suggesting nested subdomains");
    if (!features.has_https) riskFactors.push("No HTTPS encryption (insecure connection)");
    if (features.has_double_slash_redirect) riskFactors.push("Contains redirect indicators (multiple //)");

    let predictionLabel, riskLevel;
    if (prediction === 1) {
      predictionLabel = "Phishing/Malicious";
      riskLevel = confidence > 80 ? "Potentially Malicious" : "Suspicious";
    } else {
      predictionLabel = "Legitimate";
      riskLevel = confidence > 90 ? "Likely Safe" : "Low Risk";
    }

    return {
      predictionLabel,
      confidence,
      riskLevel,
      riskFactors,
      details: riskFactors.length ? riskFactors.join("; ") : "No obvious risk factors detected",
      features,
      proba,
    };
  }

  const URGENCY_WORDS = ["urgent", "immediately", "now", "limited", "expires", "deadline", "today only", "final"];
  const CREDENTIAL_WORDS = ["password", "otp", "pin", "cvv", "card number", "account number"];
  const SCAM_WORDS = ["winner", "won", "lottery", "prize", "free", "gift", "claim", "bonus"];
  const THREAT_WORDS = ["suspend", "blocked", "deactivate", "closed", "frozen", "penalty", "disconnection"];
  const FINANCIAL_WORDS = ["bank", "refund", "transfer", "payment", "money", "invest"];

  function analyzeMessage(text) {
    const models = global.CYBER_MODELS;
    const sparseX = tfidfTransform(models.naive_bayes, text);
    const { prediction, proba } = nbPredict(models.naive_bayes, sparseX);
    const confidence = Math.max.apply(null, proba) * 100;

    const patterns = [];
    const urlsInMsg = text.match(/http[s]?:\/\/[^\s]+/g) || [];
    if (urlsInMsg.length) patterns.push("Contains " + urlsInMsg.length + " URL(s) - verify destination carefully");
    const lower = text.toLowerCase();
    const foundUrgency = URGENCY_WORDS.filter((w) => lower.indexOf(w) !== -1);
    if (foundUrgency.length) patterns.push("Urgency pressure language detected: " + foundUrgency.join(", "));
    const foundCred = CREDENTIAL_WORDS.filter((w) => lower.indexOf(w) !== -1);
    if (foundCred.length) patterns.push("Requests sensitive credentials: " + foundCred.join(", "));
    const foundScam = SCAM_WORDS.filter((w) => lower.indexOf(w) !== -1);
    if (foundScam.length) patterns.push("Too-good-to-be-true keywords: " + foundScam.join(", "));
    const foundThreats = THREAT_WORDS.filter((w) => lower.indexOf(w) !== -1);
    if (foundThreats.length) patterns.push("Account threat language: " + foundThreats.join(", "));
    const foundFin = FINANCIAL_WORDS.filter((w) => lower.indexOf(w) !== -1);
    if (foundFin.length) patterns.push("Financial references: " + foundFin.join(", "));

    let predictionLabel, riskLevel;
    if (prediction === 1) {
      predictionLabel = "Phishing";
      riskLevel = confidence > 75 ? "Phishing Detected" : "Suspicious";
    } else {
      predictionLabel = "Legitimate";
      riskLevel = "Likely Safe";
    }

    return {
      predictionLabel,
      confidence,
      riskLevel,
      patterns,
      details: patterns.length ? patterns.slice(0, 10).join("; ") : "No suspicious patterns detected",
      proba,
    };
  }

  global.CyberML = { extractUrlFeatures, analyzeUrl, analyzeMessage };
})(window);

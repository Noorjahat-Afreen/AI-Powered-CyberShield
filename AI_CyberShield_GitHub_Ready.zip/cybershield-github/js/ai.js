/**
 * AI Cyber Expert layer - browser calls to Z.ai GLM (OpenAI-compatible) or
 * Google Gemini. Provider is auto-detected from the key prefix in config.js.
 *
 * Design guarantees:
 *  - Never blocks the core ML features (they run fully offline).
 *  - Every failure degrades to an honest, clearly-labelled status message.
 */
(function (global) {
  "use strict";

  const CFG = () => global.CYBER_CONFIG || {};

  function resolveProvider() {
    const c = CFG();
    const choice = (c.AI_PROVIDER || "auto").toLowerCase();
    const zaiKey = (c.ZAI_API_KEY || "").trim();
    const gemKey = (c.GEMINI_API_KEY || "").trim();
    if (choice === "off") return null;
    if (choice === "gemini") return gemKey ? "gemini" : null;
    if (choice === "zai") return zaiKey ? "zai" : null;
    // auto: prefix wins, zai key by default
    if (gemKey.startsWith("AIza")) return "gemini";
    if (zaiKey) return "zai";
    if (gemKey) return "gemini";
    return null;
  }

  async function fetchWithTimeout(url, options, timeoutMs) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs || 45000);
    try {
      return await fetch(url, { ...options, signal: controller.signal });
    } finally {
      clearTimeout(timer);
    }
  }

  async function callZai(prompt, system) {
    const c = CFG();
    const res = await fetchWithTimeout(c.ZAI_BASE_URL + "/chat/completions", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: "Bearer " + c.ZAI_API_KEY },
      body: JSON.stringify({
        model: c.ZAI_MODEL || "glm-4.6",
        messages: [
          ...(system ? [{ role: "system", content: system }] : []),
          { role: "user", content: prompt },
        ],
        temperature: 0.4,
        max_tokens: 700,
      }),
    }, c.AI_TIMEOUT_MS);
    if (!res.ok) {
      const detail = res.status === 401 ? "authentication failed (key invalid or not activated)"
        : res.status === 429 ? "rate limited by the provider"
        : "HTTP " + res.status;
      throw new Error(detail);
    }
    const data = await res.json();
    const text = data && data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content;
    if (!text) throw new Error("empty response");
    return text;
  }

  async function callGemini(prompt, system) {
    const c = CFG();
    const url = "https://generativelanguage.googleapis.com/v1beta/models/" +
      (c.GEMINI_MODEL || "gemini-2.0-flash") + ":generateContent?key=" + encodeURIComponent(c.GEMINI_API_KEY);
    const res = await fetchWithTimeout(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents: [{ parts: [{ text: prompt }] }],
        ...(system ? { systemInstruction: { parts: [{ text: system }] } } : {}),
        generationConfig: { temperature: 0.4, maxOutputTokens: 700 },
      }),
    }, c.AI_TIMEOUT_MS);
    if (!res.ok) {
      const detail = res.status === 401 || res.status === 403 ? "authentication failed (key invalid or restricted)"
        : res.status === 429 ? "rate limited by the provider"
        : "HTTP " + res.status;
      throw new Error(detail);
    }
    const data = await res.json();
    const parts = data && data.candidates && data.candidates[0] && data.candidates[0].content && data.candidates[0].content.parts;
    const text = parts && parts.map((p) => p.text || "").join("");
    if (!text) throw new Error("empty response");
    return text;
  }

  /**
   * Ask the AI provider. Resolves {ok, text, provider} or {ok:false, error}.
   * Never throws.
   */
  async function askAI(prompt, system) {
    const provider = resolveProvider();
    if (!provider) {
      return { ok: false, error: "No AI key configured in config.js" };
    }
    try {
      const text = provider === "gemini" ? await callGemini(prompt, system) : await callZai(prompt, system);
      return { ok: true, text, provider: provider === "gemini" ? "Google Gemini" : "Z.ai GLM" };
    } catch (err) {
      const msg = err && err.name === "AbortError" ? "request timed out" : (err && err.message) || "request failed";
      return { ok: false, error: msg, provider };
    }
  }

  function aiStatus() {
    const provider = resolveProvider();
    return {
      configured: provider !== null,
      provider: provider === "gemini" ? "Google Gemini" : provider === "zai" ? "Z.ai GLM" : null,
    };
  }

  const SYSTEM_PROMPT = [
    "You are the AI Cyber Expert inside CyberShield, an educational cybersecurity training project.",
    "You analyse phishing risks. Be concise, practical and safe: never provide offensive hacking steps.",
    "Structure answers with short paragraphs or small bullet lists. Answer in the user's language.",
  ].join(" ");

  function explainScan(kind, input, result) {
    const summary = kind === "url"
      ? "URL: " + input + "\nML verdict: " + result.predictionLabel + " (confidence " + result.confidence.toFixed(1) + "%)" +
        "\nExtracted features: " + JSON.stringify(result.features)
      : "Message: " + input + "\nML verdict: " + result.predictionLabel + " (confidence " + result.confidence.toFixed(1) + "%)";
    const prompt =
      summary +
      "\n\nExplain for a student: 1) why the model reached this verdict, 2) the top risk signs to check manually," +
      " 3) one recommended action. Maximum 150 words.";
    return askAI(prompt, SYSTEM_PROMPT);
  }

  global.CyberAI = { askAI, aiStatus, explainScan, SYSTEM_PROMPT };
})(window);

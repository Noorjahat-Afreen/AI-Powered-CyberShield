/**
 * AI CyberShield - site configuration.
 *
 * === IMPORTANT SECURITY NOTE ==========================================
 * This file is PUBLIC when hosted on GitHub Pages. Anyone can read the key
 * you place here. Use a key with a spending limit / quota cap, and rotate it
 * if it leaks. For a private setup, leave the keys empty - every ML feature
 * of this site works fully offline without any key.
 * ======================================================================
 *
 * Supported AI providers (auto-detected from the key prefix):
 *   - Z.ai GLM      : key starts with "AQ."   -> OpenAI-compatible endpoint
 *   - Google Gemini : key starts with "AIza"  -> generativelanguage.googleapis.com
 */
window.CYBER_CONFIG = {
  // Primary key configured for this project (Z.ai / GLM):
  ZAI_API_KEY: "AQ.Ab8RN6JLlShJaW_-GnWPH5c4np2tADZnM8pHhqy40nRs-VrQ3g",
  ZAI_BASE_URL: "https://api.z.ai/api/paas/v4",
  ZAI_MODEL: "glm-4.6",

  // Optional alternative - paste a Google AI Studio key here (starts with AIza):
  GEMINI_API_KEY: "",
  GEMINI_MODEL: "gemini-2.0-flash",

  // auto | zai | gemini | off
  AI_PROVIDER: "auto",

  AI_TIMEOUT_MS: 45000,
};

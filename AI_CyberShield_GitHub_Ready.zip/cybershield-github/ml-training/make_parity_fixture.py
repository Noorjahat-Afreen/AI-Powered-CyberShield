"""Generate a parity-test fixture: sklearn predictions on diverse inputs."""
from __future__ import annotations

import json
import random
import re
import joblib
import pandas as pd

random.seed(7)

url_model = joblib.load("models/url_model.pkl")
url_features = joblib.load("models/url_features.pkl")
nb = joblib.load("models/message_model.pkl")
vec = joblib.load("models/message_vectorizer.pkl")


def extract_url_features(url):
    features = {}
    features['url_length'] = len(url)
    features['num_dots'] = url.count('.')
    features['num_hyphens'] = url.count('-')
    features['num_underscores'] = url.count('_')
    features['num_slashes'] = url.count('/')
    features['num_digits'] = sum(c.isdigit() for c in url)
    features['has_ip'] = 1 if re.search(r'\d+\.\d+\.\d+\.\d+', url) else 0
    features['has_at'] = 1 if '@' in url else 0
    features['has_https'] = 1 if url.startswith('https') else 0
    features['has_port'] = 1 if ':' in url.split('//')[-1].split('/')[0] else 0
    features['num_subdomains'] = url.split('//')[-1].split('/')[0].count('.') if '//' in url else url.count('.')
    suspicious_tlds = ['.tk', '.ml', '.ga', '.cf', '.gq', '.top', '.xyz', '.club', '.work', '.click']
    features['suspicious_tld'] = 1 if any(tld in url.lower() for tld in suspicious_tlds) else 0
    suspicious_words = ['login', 'verify', 'update', 'secure', 'account', 'password', 'bank',
                        'free', 'winner', 'prize', 'gift', 'claim', 'urgent', 'suspended',
                        'limited', 'offer', 'bonus', 'discount', 'refund']
    features['num_suspicious_words'] = sum(1 for word in suspicious_words if word.lower() in url.lower())
    features['has_double_slash_redirect'] = 1 if url.count('//') > 1 else 0
    features['has_percent'] = 1 if '%' in url else 0
    features['has_equal_sign'] = 1 if '=' in url else 0
    features['has_question'] = 1 if '?' in url else 0
    return features


# ---- test corpus: training samples + fresh never-seen URLs ----
df = pd.read_csv("data/urls_dataset.csv")
train_urls = df["url"].tolist()
fresh = [
    "https://www.zerodha.com/kite", "http://203.0.113.45/paypal-login.php",
    "https://sbi-online-urgent-update.top/verify-account?ref=991",
    "http://free-discount-bonus-offer.club/claim?id=88&x=%20",
    "https://mail.proton.me/inbox", "http://win-free-gift-now.click/prize",
    "https://www.icicibank.com/safe-online-banking", "http://secure-verify-account-password.gq/login",
    "https://github.com/microsoft/vscode/issues?q=bug", "http://199.99.99.99:8080/admin/",
    "https://docs.python.org/3/library/re.html", "http://update-your-bank-account.tk/secure/login",
    "https://www.amazon.in/dp/B0ABC123?ref_=ox_search", "http://limited-offer-urgent-refund.work/claim",
    "https://www.flipkart.com/offers/list?q=discount", "http://verify-identity-suspended-account.xyz/",
]
test_urls = train_urls + fresh
random.shuffle(test_urls)
test_urls = test_urls[:250]

url_rows = []
for u in test_urls:
    feats = extract_url_features(u)
    vals = [feats[f] for f in url_features]
    pdf = pd.DataFrame([vals], columns=url_features)
    pred = int(url_model.predict(pdf)[0])
    proba = url_model.predict_proba(pdf)[0]
    url_rows.append({"url": u, "pred": pred, "proba": [round(float(p), 8) for p in proba]})

# ---- messages: training samples + fresh texts ----
mdf = pd.read_csv("data/messages_dataset.csv")
train_msgs = mdf["text"].tolist()
fresh_msgs = [
    "Hey, are we still on for dinner tonight at 8?",
    "URGENT: Your account will be suspended today. Verify now: http://bad-link.tk",
    "You won a free prize! Claim immediately at http://scam.example.ga",
    "The quarterly results presentation is shared on the portal.",
    "Your KYC expires today. Update password and OTP here: http://kyc-verify.cf",
    "Reminder: paytm wallet cashback offer ends tonight, invest money now http://x.ml",
    "Please review the attached contract and sign by Friday.",
    "Congratulations winner! You have won the lottery. Send card number to claim.",
    "The doctor appointment is confirmed for Tuesday 11 AM.",
    "Your ATM card was blocked. Transfer money to unblock: http://bank-urgent.tk",
]
test_msgs = train_msgs + fresh_msgs
random.shuffle(test_msgs)
test_msgs = test_msgs[:250]

msg_rows = []
for t in test_msgs:
    x = vec.transform([t])
    pred = int(nb.predict(x)[0])
    proba = nb.predict_proba(x)[0]
    msg_rows.append({"text": t, "pred": pred, "proba": [round(float(p), 8) for p in proba]})

fixture = {"urls": url_rows, "messages": msg_rows}
with open("scripts/parity_fixture.json", "w") as fh:
    json.dump(fixture, fh)
print(f"fixture: {len(url_rows)} urls, {len(msg_rows)} messages")

/**
 * Parity test: JS browser engine vs sklearn fixture.
 * Run: node scripts/parity_test.mjs
 * Requires: js/models.js + js/analyzer.js (window shimmed) + scripts/parity_fixture.json
 */
import { readFileSync } from "node:fs";

globalThis.window = globalThis;
globalThis.CYBER_MODELS = undefined;
eval(readFileSync("cybershield-website/js/models.js", "utf8"));
eval(readFileSync("cybershield-website/js/analyzer.js", "utf8"));

const fixture = JSON.parse(readFileSync("scripts/parity_fixture.json", "utf8"));

let urlOk = 0, urlBad = [], probaErr = 0;
for (const row of fixture.urls) {
  const r = window.CyberML.analyzeUrl(row.url);
  const pred = r.predictionLabel === "Phishing/Malicious" ? 1 : 0;
  if (pred !== row.pred) urlBad.push({ url: row.url, js: pred, py: row.pred });
  else urlOk++;
  probaErr = Math.max(probaErr, Math.abs(r.proba[row.pred] - row.proba[row.pred]));
}

let msgOk = 0, msgBad = [], msgProbaErr = 0;
for (const row of fixture.messages) {
  const r = window.CyberML.analyzeMessage(row.text);
  const pred = r.predictionLabel === "Phishing" ? 1 : 0;
  if (pred !== row.pred) msgBad.push({ text: row.text.slice(0, 60), js: pred, py: row.pred });
  else msgOk++;
  msgProbaErr = Math.max(msgProbaErr, Math.abs(r.proba[row.pred] - row.proba[row.pred]));
}

console.log(`URL:     ${urlOk}/${fixture.urls.length} exact  | max proba diff ${probaErr.toExponential(2)}`);
console.log(`Message: ${msgOk}/${fixture.messages.length} exact  | max proba diff ${msgProbaErr.toExponential(2)}`);
if (urlBad.length) console.log("URL mismatches:", urlBad.slice(0, 5));
if (msgBad.length) console.log("MSG mismatches:", msgBad.slice(0, 5));
if (urlBad.length || msgBad.length) {
  console.log("PARITY FAILED");
  process.exit(1);
}
console.log("PARITY PASSED - JS engine matches sklearn exactly");

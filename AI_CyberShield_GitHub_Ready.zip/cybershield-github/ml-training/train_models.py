"""
AI-Powered CyberShield - ML Model Training Script
==================================================
Trains 2 machine learning models:
1. URL Phishing Detector (Random Forest)
2. Message Phishing Detector (Naive Bayes + TF-IDF)

Run: python train_models.py
"""

import pandas as pd
import numpy as np
import re
import os
import joblib
from sklearn.ensemble import RandomForestClassifier
from sklearn.naive_bayes import MultinomialNB
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report

# Create directories
os.makedirs("data", exist_ok=True)
os.makedirs("models", exist_ok=True)
np.random.seed(42)

# ============================================
# URL Feature Extraction Function
# ============================================

def extract_url_features(url):
    """Extract 20 features from a URL for ML classification"""
    features = {}
    features['url_length'] = len(url)
    features['num_dots'] = url.count('.')
    features['num_hyphens'] = url.count('-')
    features['num_underscores'] = url.count('_')
    features['num_slashes'] = url.count('/')
    features['num_digits'] = sum(c.isdigit() for c in url)
    features['has_ip'] = 1 if re.search(r'\d+\.\d+\.\d+\.\d+', url) else 0
    features['has_at'] = 1 if '@' in url else 0
    features['has_https'] = 1 if url.startswith('https') else 0
    features['has_port'] = 1 if ':' in url.split('//')[-1].split('/')[0] else 0
    features['num_subdomains'] = url.split('//')[-1].split('/')[0].count('.') if '//' in url else url.count('.')
    suspicious_tlds = ['.tk', '.ml', '.ga', '.cf', '.gq', '.top', '.xyz', '.club', '.work', '.click']
    features['suspicious_tld'] = 1 if any(tld in url.lower() for tld in suspicious_tlds) else 0
    suspicious_words = ['login', 'verify', 'update', 'secure', 'account', 'password', 'bank',
                        'free', 'winner', 'prize', 'gift', 'claim', 'urgent', 'suspended',
                        'limited', 'offer', 'bonus', 'discount', 'refund']
    features['num_suspicious_words'] = sum(1 for word in suspicious_words if word.lower() in url.lower())
    features['has_double_slash_redirect'] = 1 if url.count('//') > 1 else 0
    features['has_percent'] = 1 if '%' in url else 0
    features['has_equal_sign'] = 1 if '=' in url else 0
    features['has_question'] = 1 if '?' in url else 0
    return features


# ============================================
# PART 1: URL Dataset + Model Training
# ============================================

print("=" * 60)
print("  AI CyberShield - ML Model Training")
print("=" * 60)
print()
print("[1/3] Building URL dataset...")

# Legitimate URLs (real popular websites)
legit_urls = [
    "https://www.google.com/search?q=python", "https://www.facebook.com/home",
    "https://www.amazon.in/products/laptop", "https://www.youtube.com/watch?v=abc123",
    "https://github.com/user/repo", "https://www.linkedin.com/in/profile",
    "https://www.twitter.com/home", "https://www.instagram.com/explore",
    "https://www.microsoft.com/windows", "https://www.apple.com/iphone",
    "https://www.netflix.com/browse", "https://www.flipkart.com/mobiles",
    "https://mail.google.com/inbox", "https://docs.google.com/document",
    "https://stackoverflow.com/questions", "https://www.reddit.com/r/python",
    "https://www.wikipedia.org/wiki/Python", "https://www.quora.com/question",
    "https://www.medium.com/article", "https://www.bbc.com/news",
    "https://www.cnn.com/world", "https://www.ndtv.com/india",
    "https://www.hindustantimes.com", "https://www.timesofindia.com",
    "https://www.irctc.co.in/book", "https://www.onlinesbi.com/login",
    "https://www.hdfcbank.com/netbanking", "https://www.icicibank.com/personal",
    "https://www.axisbank.com/login", "https://paytm.com/recharge",
    "https://www.phonepe.com/pay", "https://www.swiggy.com/order",
    "https://www.zomato.com/restaurants", "https://www.uber.com/ride",
    "https://www.ola.com/book", "https://www.makemytrip.com/flights",
    "https://www.goibibo.com/hotels", "https://www.cleartrip.com/trains",
    "https://www.bookmyshow.com/movies", "https://www.hotstar.com/watch",
    "https://www.primevideo.com/movie", "https://www.spotify.com/playlist",
    "https://open.spotify.com/artist", "https://www.samsung.com/mobiles",
    "https://www.dell.com/laptops", "https://www.hp.com/printers",
    "https://www.lenovo.com/computers", "https://www.asus.com/monitors",
    "https://www.logitech.com/mouse", "https://www.intel.com/processors",
]

# Phishing/malicious URLs (realistic scam patterns)
phishing_urls = [
    "http://192.168.1.1/login.php", "http://10.0.0.1/admin/login",
    "http://secure-paypal-update.com/login", "http://paypal-verify-account.tk/login",
    "http://amaz0n-verify-account.ml/login", "http://amazon-update-security.ga/login",
    "http://bank0findia-secure-login.tk/", "http://hdfc-netbanking-update.cf/login",
    "http://icici-secure-verify.ml/verify", "http://sbi-online-update.tk/login",
    "https://free-prize-winner.tk/claim", "http://you-won-lottery.ml/prize",
    "http://free-gift-card-giveaway.ga/claim", "http://congrats-winner.cf/prize",
    "http://account-update-required.ml/secure", "http://verify-your-account.tk/login",
    "http://update-payment-info.cf/secure", "http://suspended-account.ga/verify",
    "http://login-verify-account.tk/secure", "http://password-reset-required.ml/login",
    "http://free-money-transfer.tk/signup", "http://get-rich-quick.ml/invest",
    "http://double-your-money.cf/invest", "http://bitcoin-mining-free.ga/signup",
    "http://free-crypto-airdrop.tk/claim", "http://nft-giveaway-free.ml/claim",
    "http://secure-bank-login-update.tk/login", "http://bank-verify-identity.ml/secure",
    "http://online-banking-update.cf/login", "http://netbanking-secure-verify.ga/login",
    "http://tax-refund-claim.tk/refund", "http://income-tax-refund.ml/claim",
    "http://gst-refund-secure.cf/claim", "http://govt-scheme-apply.ga/apply",
    "http://free-mobile-recharge.tk/recharge", "http://free-data-pack.ml/claim",
    "http://free-shopping-voucher.cf/claim", "http://discount-sale-90-off.ga/shop",
    "http://fake-login-page.tk/google", "http://phishing-login.ml/facebook",
    "http://clone-site-login.cf/amazon", "http://fake-secure-login.ga/paypal",
    "http://malware-download.tk/free-software", "http://virus-scan-free.ml/scan",
    "http://free-antivirus-download.cf/download", "http://crack-software-free.ga/download",
    "http://pirated-movies-download.tk/download", "http://free-movie-stream.ml/watch",
    "http://adult-content-free.cf/access", "http://dating-site-free.ga/signup",
]

# Build feature dataset
url_data = []
for url in legit_urls:
    feats = extract_url_features(url)
    feats['label'] = 0  # 0 = legitimate
    feats['url'] = url
    url_data.append(feats)

for url in phishing_urls:
    feats = extract_url_features(url)
    feats['label'] = 1  # 1 = phishing
    feats['url'] = url
    url_data.append(feats)

url_df = pd.DataFrame(url_data)
url_df = url_df.sample(frac=1, random_state=42).reset_index(drop=True)
url_df.to_csv("data/urls_dataset.csv", index=False)
print(f"    Saved data/urls_dataset.csv ({len(url_df)} samples)")

# Train URL model
feature_cols = [c for c in url_df.columns if c not in ['label', 'url']]
X_url = url_df[feature_cols]
y_url = url_df['label']

X_train, X_test, y_train, y_test = train_test_split(X_url, y_url, test_size=0.2, random_state=42, stratify=y_url)

url_model = RandomForestClassifier(n_estimators=100, max_depth=10, random_state=42)
url_model.fit(X_train, y_train)

y_pred = url_model.predict(X_test)
url_accuracy = accuracy_score(y_test, y_pred)
print(f"    URL Model Accuracy: {url_accuracy:.2%}")

joblib.dump(url_model, "models/url_model.pkl")
joblib.dump(feature_cols, "models/url_features.pkl")
print("    Saved models/url_model.pkl")


# ============================================
# PART 2: Message Dataset + Model Training
# ============================================

print()
print("[2/3] Building message dataset...")

legit_messages = [
    "Hi, can we meet tomorrow at 3 PM for the project discussion?",
    "Your order has been shipped and will arrive by Friday.",
    "Don't forget the team meeting at 10 AM tomorrow.",
    "Thanks for your email. I'll get back to you soon.",
    "The report is ready for your review.",
    "Happy birthday! Have a great day ahead.",
    "Please find the attached invoice for your reference.",
    "Your subscription will renew next month.",
    "Can you send me the meeting notes?",
    "The project deadline has been extended to next Friday.",
    "Congratulations on your promotion!",
    "Your flight booking is confirmed. PNR: ABC123.",
    "Please review the document and share your feedback.",
    "The office will remain closed on Monday for the holiday.",
    "Your package is out for delivery today.",
    "Join us for the team lunch this Friday at 1 PM.",
    "The exam results will be announced next week.",
    "Please submit your assignment by Friday.",
    "Your appointment is confirmed for tomorrow at 2 PM.",
    "Thanks for shopping with us. Visit again!",
    "The monthly report has been shared with all managers.",
    "Reminder: The vendor call is scheduled for Thursday.",
    "Your medical test reports are normal. No concerns.",
    "The library books are due back next Wednesday.",
    "Parent teacher meeting is scheduled for Saturday.",
    "The cab will pick you up from the main gate at 6 PM.",
    "Your salary has been credited for this month.",
    "The new office policy document is available on the intranet.",
    "Team building activity is planned for next month.",
    "The client approved the design mockups yesterday.",
    "Please water the plants while I am away for a week.",
    "The restaurant reservation is confirmed for 8 people.",
    "Your gym membership renewal is due next week.",
    "The workshop registration closes on Friday evening.",
    "Weather forecast shows rain this weekend, plan accordingly.",
    "The seminar on AI will be held in the auditorium.",
    "Your request for leave has been approved by HR.",
    "The software update will be installed tonight at midnight.",
    "Breakfast will be served complimentary from 7 to 10 AM.",
    "The conference call details have been emailed to you.",
    "Please confirm your attendance for the annual day event.",
    "The maintenance work in building B is completed.",
    "Your luggage claim tag number is 4523.",
    "The lecture slides have been uploaded to the portal.",
    "Congratulations to the winning team of the hackathon!",
    "The canteen now accepts digital payment methods.",
    "YourFeedback on the new website design is appreciated.",
    "The shuttle service runs every 30 minutes from the metro.",
    "The guest lecture by the industry expert is postponed.",
    "The sports meet will begin from the coming Monday.",
]

phishing_messages = [
    "URGENT: Your bank account has been suspended. Click here to verify: http://suspicious-link.tk",
    "Congratulations! You've won $1,000,000. Claim your prize now: http://fake-prize.ml",
    "Your Amazon account has been locked. Verify immediately: http://amaz0n-verify.ga",
    "Dear customer, your ATM card has been blocked. Click to unblock: http://bank-update.cf",
    "You have a pending tax refund of Rs 50,000. Claim now: http://tax-refund.tk",
    "Your PayPal account has unusual activity. Verify now: http://paypal-secure.ml",
    "FREE iPhone 15 giveaway! Limited time offer. Click: http://free-iphone.ga",
    "Your Netflix subscription expired. Renew now: http://netflix-update.tk",
    "URGENT: Password expired. Reset now or lose access: http://password-reset.ml",
    "You've been selected for a free gift card. Claim: http://free-gift.cf",
    "Your package delivery failed. Reschedule now: http://delivery-fail.tk",
    "Invest Rs 1000 and get Rs 50000 in 24 hours. Join now: http://invest-quick.ml",
    "Your Instagram account has been hacked. Secure now: http://insta-secure.ga",
    "Congratulations! You're our lucky winner today. Claim: http://winner-today.tk",
    "Your electricity bill is pending. Pay now to avoid disconnection: http://bill-pay.ml",
    "FREE Bitcoin giveaway! Claim your share now: http://free-btc.ga",
    "Your WhatsApp account will be deactivated. Verify: http://whatsapp-verify.tk",
    "Get a personal loan approved in 5 minutes. Apply now: http://quick-loan.ml",
    "Your computer has been infected with a virus. Download: http://virus-scan.tk",
    "You have won a holiday package worth Rs 10 lakh. Claim within 24 hours: http://holiday-win.ga",
    "Dear user, verify your KYC immediately or account will be frozen: http://kyc-update.tk",
    "Your credit card reward points are expiring today. Redeem now: http://points-redeem.ml",
    "Work from home and earn Rs 50000 weekly. No investment needed: http://wfh-earn.ga",
    "Your electricity will be cut off tonight. Make urgent payment: http://urgent-pay.cf",
    "Exclusive offer just for you! 90% discount expires in 1 hour: http://flash-sale.tk",
    "Your mobile number won a lucky draw. Send details to claim: http://lucky-draw.ml",
    "Security alert: New login from unknown device. Verify: http://login-alert.ga",
    "Your social media account needs immediate verification: http://social-verify.tk",
    "Get your free COVID insurance policy now. Limited slots: http://free-insurance.cf",
    "Your parcel is held at customs. Pay fee to release: http://customs-fee.ml",
    "Bank notice: Update your PAN card details today: http://pan-update.tk",
    "You are pre-approved for a credit card with zero fees: http://credit-offer.ga",
    "Your email storage is full. Upgrade immediately to avoid deletion: http://storage-up.cf",
    "Free recharge of Rs 500 for all users today only: http://free-recharge.tk",
    "Your IT return has errors. Fix now to avoid penalty: http://it-fix.ml",
    "Congratulations on winning the online quiz! Claim reward: http://quiz-win.ga",
    "Your debit card was used in a foreign country. Confirm: http://card-alert.tk",
    "Urgent: Your health insurance policy is about to lapse: http://health-urgent.ml",
    "Send this message to 10 friends to get free data pack: http://chain-msg.cf",
    "Your online exam fee is pending. Pay immediately: http://exam-fee.tk",
    "You are selected for a mystery shopping job. Earn daily: http://mystery-job.ga",
    "Claim your free smartwatch now. Only 5 left in stock: http://free-watch.ml",
    "Your domain certificate needs renewal to avoid suspension: http://domain-cert.cf",
    "Get a free trial of premium membership. No card needed: http://premium-free.tk",
    "Your portfolio photo contest entry won first prize: http://photo-win.ga",
    "Instant personal loan without documents. Apply in 2 minutes: http://instant-loan.ml",
    "Your SIM card will expire today. Verify to keep active: http://sim-active.cf",
    "You received a money transfer of Rs 25000. Accept now: http://money-in.tk",
    "Limited seats left for the free coding bootcamp. Register: http://bootcamp-free.ga",
    "Your car insurance premium is due. Pay now to avoid penalty: http://car-ins.ml",
]

msg_data = []
for msg in legit_messages:
    msg_data.append({'text': msg, 'label': 0})
for msg in phishing_messages:
    msg_data.append({'text': msg, 'label': 1})

msg_df = pd.DataFrame(msg_data)
msg_df = msg_df.sample(frac=1, random_state=42).reset_index(drop=True)
msg_df.to_csv("data/messages_dataset.csv", index=False)
print(f"    Saved data/messages_dataset.csv ({len(msg_df)} samples)")

# Train message model
X_msg = msg_df['text']
y_msg = msg_df['label']

X_train_m, X_test_m, y_train_m, y_test_m = train_test_split(X_msg, y_msg, test_size=0.2, random_state=42, stratify=y_msg)

vectorizer = TfidfVectorizer(max_features=1000, stop_words='english', ngram_range=(1, 2))
X_train_vec = vectorizer.fit_transform(X_train_m)
X_test_vec = vectorizer.transform(X_test_m)

msg_model = MultinomialNB()
msg_model.fit(X_train_vec, y_train_m)

y_pred_m = msg_model.predict(X_test_vec)
msg_accuracy = accuracy_score(y_test_m, y_pred_m)
print(f"    Message Model Accuracy: {msg_accuracy:.2%}")

joblib.dump(msg_model, "models/message_model.pkl")
joblib.dump(vectorizer, "models/message_vectorizer.pkl")
print("    Saved models/message_model.pkl")


# ============================================
# Summary
# ============================================

print()
print("=" * 60)
print("  ALL MODELS TRAINED SUCCESSFULLY!")
print("=" * 60)
print(f"  URL Phishing Detection     : {url_accuracy:.2%} accuracy")
print(f"  Message Phishing Detection : {msg_accuracy:.2%} accuracy")
print("=" * 60)
print()
print("Files created:")
print("  data/urls_dataset.csv")
print("  data/messages_dataset.csv")
print("  models/url_model.pkl")
print("  models/url_features.pkl")
print("  models/message_model.pkl")
print("  models/message_vectorizer.pkl")
print()
print("You can now run: streamlit run app.py")

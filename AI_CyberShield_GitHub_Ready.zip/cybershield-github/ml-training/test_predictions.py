"""Test ML prediction functions from app.py logic"""
import joblib
import re


def extract_url_features(url):
    features = {}
    features['url_length'] = len(url)
    features['num_dots'] = url.count('.')
    features['num_hyphens'] = url.count('-')
    features['num_underscores'] = url.count('_')
    features['num_slashes'] = url.count('/')
    features['num_digits'] = sum(c.isdigit() for c in url)
    features['has_ip'] = 1 if re.search(r'\d+\.\d+\.\d+\.\d+', url) else 0
    features['has_at'] = 1 if '@' in url else 0
    features['has_https'] = 1 if url.startswith('https') else 0
    features['has_port'] = 1 if ':' in url.split('//')[-1].split('/')[0] else 0
    features['num_subdomains'] = url.split('//')[-1].split('/')[0].count('.') if '//' in url else url.count('.')
    suspicious_tlds = ['.tk', '.ml', '.ga', '.cf', '.gq', '.top', '.xyz', '.club', '.work', '.click']
    features['suspicious_tld'] = 1 if any(tld in url.lower() for tld in suspicious_tlds) else 0
    suspicious_words = ['login', 'verify', 'update', 'secure', 'account', 'password', 'bank',
                        'free', 'winner', 'prize', 'gift', 'claim', 'urgent', 'suspended',
                        'limited', 'offer', 'bonus', 'discount', 'refund']
    features['num_suspicious_words'] = sum(1 for word in suspicious_words if word.lower() in url.lower())
    features['has_double_slash_redirect'] = 1 if url.count('//') > 1 else 0
    features['has_percent'] = 1 if '%' in url else 0
    features['has_equal_sign'] = 1 if '=' in url else 0
    features['has_question'] = 1 if '?' in url else 0
    return features


url_model = joblib.load("models/url_model.pkl")
url_features = joblib.load("models/url_features.pkl")
msg_model = joblib.load("models/message_model.pkl")
msg_vectorizer = joblib.load("models/message_vectorizer.pkl")

print("=" * 60)
print("TESTING URL SCANNER (Real ML Predictions)")
print("=" * 60)

test_urls = [
    ("https://www.google.com", "Legitimate"),
    ("https://github.com/user/repo", "Legitimate"),
    ("http://paypal-verify-account.tk/login", "Phishing"),
    ("http://free-gift-card-giveaway.ga/claim", "Phishing"),
    ("http://192.168.1.1/login.php", "Phishing"),
]

passed = 0
for url, expected in test_urls:
    feats = extract_url_features(url)
    vals = [feats[f] for f in url_features]
    pred = url_model.predict([vals])[0]
    proba = url_model.predict_proba([vals])[0] * 100
    label = "Phishing/Malicious" if pred == 1 else "Legitimate"
    match = ("Phishing" in expected and pred == 1) or ("Legitimate" in expected and pred == 0)
    if match:
        passed += 1
    status = "PASS" if match else "FAIL"
    print(f"[{status}] {url[:45]:45s} -> {label:20s} ({max(proba):.1f}%)")

print(f"\nURL Scanner: {passed}/{len(test_urls)} tests passed")

print()
print("=" * 60)
print("TESTING MESSAGE DETECTOR (Real ML Predictions)")
print("=" * 60)

test_msgs = [
    ("Hi, can we meet tomorrow at 3 PM for the project discussion?", "Legitimate"),
    ("Your order has been shipped and will arrive by Friday.", "Legitimate"),
    ("URGENT: Your bank account has been suspended. Click here to verify: http://suspicious-link.tk", "Phishing"),
    ("Congratulations! You've won $1,000,000. Claim your prize now: http://fake-prize.ml", "Phishing"),
    ("FREE iPhone 15 giveaway! Limited time offer. Click: http://free-iphone.ga", "Phishing"),
]

passed_m = 0
for msg, expected in test_msgs:
    vec = msg_vectorizer.transform([msg])
    pred = msg_model.predict(vec)[0]
    proba = msg_model.predict_proba(vec)[0] * 100
    label = "Phishing" if pred == 1 else "Legitimate"
    match = (expected == label)
    if match:
        passed_m += 1
    status = "PASS" if match else "FAIL"
    print(f"[{status}] {msg[:50]:50s} -> {label:12s} ({max(proba):.1f}%)")

print(f"\nMessage Detector: {passed_m}/{len(test_msgs)} tests passed")

print()
print("=" * 60)
print("DATABASE TEST")
print("=" * 60)
import sqlite3
conn = sqlite3.connect("cybershield.db")
c = conn.cursor()
c.execute("CREATE TABLE IF NOT EXISTS scans (id INTEGER PRIMARY KEY AUTOINCREMENT, scan_type TEXT, input_content TEXT, prediction TEXT, confidence REAL, risk_level TEXT, details TEXT, timestamp DATETIME)")
c.execute("INSERT INTO scans (scan_type, input_content, prediction, confidence, risk_level, details, timestamp) VALUES ('URL','https://www.google.com','Legitimate',95.0,'Likely Safe','No risk factors','2026-01-01 10:00:00')")
c.execute("SELECT * FROM scans")
rows = c.fetchall()
print(f"Database rows: {len(rows)} - {rows[0][2] if rows else 'empty'}")
c.execute("DELETE FROM scans")
conn.commit()
conn.close()
print("Database test: PASS")
print()
print("ALL TESTS COMPLETE!")

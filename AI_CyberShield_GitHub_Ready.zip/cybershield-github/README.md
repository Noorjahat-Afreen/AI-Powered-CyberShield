# AI CyberShield - Phishing Detection with Machine Learning

**B.Tech CSE Major Project (AI + Cybersecurity)** - a cybersecurity web app that detects
phishing URLs and suspicious messages using Machine Learning. The trained models run
**100% in the browser** - no server, no install, nothing uploaded.

Live site: `https://<your-username>.github.io/<repo-name>/` (after enabling GitHub Pages - see [DEPLOY_GITHUB.md](DEPLOY_GITHUB.md))

## What it does

| Feature | Model | Where it runs |
| --- | --- | --- |
| URL phishing scanner | Random Forest (100 trees, 17 features) | In your browser (JS port) |
| Phishing message detector | TF-IDF + Multinomial Naive Bayes (773 features) | In your browser (JS port) |
| Threat analytics | Chart.js dashboards | In your browser |
| Scan history | localStorage (never uploaded) | In your browser |
| Reports | CSV + TXT export | In your browser |
| AI Cyber Expert chat | Z.ai GLM or Google Gemini via API key | Optional (key in `config.js`) |

## How the ML works

1. **Training pipeline** (`ml-training/`): `train_models.py` builds datasets (legitimate vs
   phishing URLs/messages) and trains both scikit-learn models.
2. **Model export**: `ml-training/export_models.py` converts the trained Random Forest
   (all 100 trees) and the Naive Bayes + TF-IDF vectoriser into `js/models.js`.
3. **Browser inference**: `js/analyzer.js` reimplements scikit-learn's exact prediction
   maths (tree traversal, TF-IDF transform, Naive Bayes log-probabilities).
4. **Parity guarantee**: `ml-training/parity_test.mjs` proves the JS engine matches
   sklearn prediction-for-prediction (100% exact on held-out fixtures, probability
   differences at float-precision noise level).

So the static site is not a mock-up - it runs the real trained models.

## Project structure

```
├── index.html              # The entire app (GitHub Pages entry point)
├── config.js               # AI provider settings + API key
├── css/styles.css
├── js/
│   ├── models.js           # Trained models converted to JS (auto-generated)
│   ├── analyzer.js         # sklearn-exact inference engine
│   ├── ai.js               # Z.ai GLM / Gemini API layer (optional)
│   └── app.js              # UI logic, history, charts, reports
├── ml-training/            # Python pipeline (training + export + tests)
├── DEPLOY_GITHUB.md        # Step-by-step GitHub Pages deployment
└── .nojekyll               # Tells GitHub Pages to serve files as-is
```

## Run locally

Static site - any web server works:

```bash
python -m http.server 8000
# open http://localhost:8000
```

(Or just open `index.html` directly in a browser - everything works from file:// too,
except the AI chat which needs http/https.)

## Retrain the models (optional)

```bash
cd ml-training
pip install -r requirements.txt
python train_models.py          # creates models/*.pkl + datasets
python export_models.py         # refreshes js/models.js for the website
node parity_test.mjs            # verify JS == sklearn
```

## AI Cyber Expert (optional)

`config.js` accepts either key and auto-detects the provider:

- **Z.ai GLM** - key starts with `AQ.` (pre-configured)
- **Google Gemini** - key starts with `AIza` (paste into `GEMINI_API_KEY`)

If no key works, the site still runs every ML feature offline - the AI panel simply
says so honestly.

> **Security note:** any key placed in `config.js` becomes public on GitHub Pages.
> Use a quota-limited key and rotate it if needed.
